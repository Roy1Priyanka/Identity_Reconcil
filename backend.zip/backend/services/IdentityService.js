class IdentityService {
  constructor(contactModel) {
    this.contactModel = contactModel;
  }

  async identifyContact(email, phoneNumber) {
    try {
      if (!email && !phoneNumber) {
        throw new Error("Either email or phoneNumber must be provided");
      }

      const existingContacts = await this.contactModel.findByEmailOrPhone(
        email,
        phoneNumber
      );

      if (existingContacts.length === 0) {
        return await this.createNewPrimaryContact(email, phoneNumber);
      }

      const exactMatch = existingContacts.find(
        (contact) =>
          contact.email === email && contact.phoneNumber === phoneNumber
      );

      if (exactMatch) {
        return await this.getContactResponse(exactMatch.id);
      }

      const shouldCreateSecondary = await this.shouldCreateSecondaryContact(
        email,
        phoneNumber,
        existingContacts
      );

      if (shouldCreateSecondary) {
        return await this.createSecondaryContact(
          email,
          phoneNumber,
          existingContacts
        );
      }

      return await this.consolidateAndRespond(existingContacts);
    } catch (error) {
      console.error("Error in identifyContact:", error);
      throw error;
    }
  }

  async createNewPrimaryContact(email, phoneNumber) {
    const newContact = await this.contactModel.create({
      email,
      phoneNumber,
      linkPrecedence: "primary",
    });

    return this.formatResponse(newContact, [newContact]);
  }

  async shouldCreateSecondaryContact(email, phoneNumber, existingContacts) {
    const emailMatches = existingContacts.filter((c) => c.email === email);
    const phoneMatches = existingContacts.filter(
      (c) => c.phoneNumber === phoneNumber
    );

    if (email && phoneNumber) {
      const exactMatch = existingContacts.find(
        (c) => c.email === email && c.phoneNumber === phoneNumber
      );

      if (!exactMatch && (emailMatches.length > 0 || phoneMatches.length > 0)) {
        return true;
      }
    }

    if (
      email &&
      !phoneNumber &&
      emailMatches.length === 0 &&
      phoneMatches.length > 0
    ) {
      return true;
    }

    if (
      phoneNumber &&
      !email &&
      phoneMatches.length === 0 &&
      emailMatches.length > 0
    ) {
      return true;
    }

    return false;
  }

  async createSecondaryContact(email, phoneNumber, existingContacts) {
    let primaryContact = existingContacts.find(
      (c) => c.linkPrecedence === "primary"
    );

    if (!primaryContact) {
      const firstSecondary = existingContacts[0];
      primaryContact = await this.contactModel.findPrimaryContact(
        firstSecondary.linkedId
      );
    }

    if (!primaryContact) {
      const oldest = existingContacts.reduce((prev, current) =>
        new Date(prev.createdAt) < new Date(current.createdAt) ? prev : current
      );
      primaryContact = oldest;
    }

    const secondaryContact = await this.contactModel.create({
      email,
      phoneNumber,
      linkedId: primaryContact.id,
      linkPrecedence: "secondary",
    });

    const allContacts = await this.contactModel.findAllLinkedContacts(
      primaryContact.id
    );

    return this.formatResponse(primaryContact, allContacts);
  }

  async consolidateAndRespond(existingContacts) {
    const contactGroups = new Map();

    for (const contact of existingContacts) {
      let primaryId;

      if (contact.linkPrecedence === "primary") {
        primaryId = contact.id;
      } else {
        const primary = await this.contactModel.findPrimaryContact(
          contact.linkedId
        );
        primaryId = primary ? primary.id : contact.linkedId;
      }

      if (!contactGroups.has(primaryId)) {
        contactGroups.set(primaryId, []);
      }
      contactGroups.get(primaryId).push(contact);
    }

    if (contactGroups.size > 1) {
      const allContacts = Array.from(contactGroups.values()).flat();
      const consolidatedContacts = await this.contactModel.consolidateContacts(
        allContacts
      );
      const primaryContact = consolidatedContacts.find(
        (c) => c.linkPrecedence === "primary"
      );

      return this.formatResponse(primaryContact, consolidatedContacts);
    }

    const primaryId = Array.from(contactGroups.keys())[0];
    const primaryContact = await this.contactModel.findById(primaryId);
    const allContacts = await this.contactModel.findAllLinkedContacts(
      primaryId
    );

    return this.formatResponse(primaryContact, allContacts);
  }

  async getContactResponse(contactId) {
    const contact = await this.contactModel.findById(contactId);

    let primaryContact;
    if (contact.linkPrecedence === "primary") {
      primaryContact = contact;
    } else {
      primaryContact = await this.contactModel.findPrimaryContact(
        contact.linkedId
      );
    }

    const allContacts = await this.contactModel.findAllLinkedContacts(
      primaryContact.id
    );

    return this.formatResponse(primaryContact, allContacts);
  }

  formatResponse(primaryContact, allContacts) {
    const secondaryContacts = allContacts.filter(
      (c) => c.linkPrecedence === "secondary" && c.id !== primaryContact.id
    );

    const emails = [
      ...new Set(
        allContacts
          .map((c) => c.email)
          .filter((email) => email !== null && email !== undefined)
      ),
    ];

    const phoneNumbers = [
      ...new Set(
        allContacts
          .map((c) => c.phoneNumber)
          .filter((phone) => phone !== null && phone !== undefined)
      ),
    ];

    emails.sort();
    phoneNumbers.sort();

    const secondaryContactIds = secondaryContacts
      .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
      .map((c) => c.id);

    return {
      contact: {
        primaryContactId: primaryContact.id,
        emails,
        phoneNumbers,
        secondaryContactIds,
      },
    };
  }
}

module.exports = IdentityService;
