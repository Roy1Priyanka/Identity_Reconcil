const request = require("supertest");
const express = require("express");
const SupabaseDatabase = require("../database/supabaseDatabase");
const Contact = require("../models/Contact");
const IdentityService = require("../services/IdentityService");
const IdentityController = require("../controllers/identityController");
const createRoutes = require("../routes");
const {
  globalErrorHandler,
  notFoundHandler,
} = require("../middleware/errorHandler");

describe("Identity Reconciliation Service with Supabase", () => {
  let app;
  let database;
  let identityService;

  beforeAll(async () => {
    // Set up test environment
    process.env.NODE_ENV = "test";

    // Ensure test environment variables are set
    if (!process.env.SUPABASE_URL || !process.env.SUPABASE_ANON_KEY) {
      console.warn("Warning: Supabase credentials not found. Tests may fail.");
      console.warn(
        "Please set SUPABASE_URL and SUPABASE_ANON_KEY environment variables."
      );
    }

    // Initialize database and services
    database = new SupabaseDatabase();

    try {
      await database.initialize();
    } catch (error) {
      console.error("Failed to initialize test database:", error);
      throw error;
    }

    const contactModel = new Contact(database);
    identityService = new IdentityService(contactModel);
    const identityController = new IdentityController(identityService);

    // Set up Express app
    app = express();
    app.use(express.json());
    app.use("/api", createRoutes(identityController));
    app.use(notFoundHandler);
    app.use(globalErrorHandler);
  });

  afterAll(async () => {
    if (database) {
      await database.close();
    }
  });

  beforeEach(async () => {
    // Clean database before each test
    try {
      await database.query(
        "DELETE FROM contacts WHERE email LIKE '%test%' OR phone_number LIKE '%test%'"
      );
    } catch (error) {
      console.warn("Could not clean test data:", error.message);
    }
  });

  describe("POST /api/identify", () => {
    test("should create new primary contact when no existing contacts", async () => {
      const response = await request(app)
        .post("/api/identify")
        .send({
          email: "test@example.com",
          phoneNumber: "+1234567890",
        })
        .expect(200);

      expect(response.body).toHaveProperty("contact");
      expect(response.body.contact).toHaveProperty("primaryContactId");
      expect(response.body.contact.emails).toContain("test@example.com");
      expect(response.body.contact.phoneNumbers).toContain("+1234567890");
      expect(response.body.contact.secondaryContactIds).toHaveLength(0);
    });

    test("should return existing contact when exact match found", async () => {
      // Create initial contact
      const firstResponse = await request(app)
        .post("/api/identify")
        .send({
          email: "test2@example.com",
          phoneNumber: "+1234567891",
        })
        .expect(200);

      // Request same contact
      const secondResponse = await request(app)
        .post("/api/identify")
        .send({
          email: "test2@example.com",
          phoneNumber: "+1234567891",
        })
        .expect(200);

      expect(secondResponse.body.contact.primaryContactId).toBe(
        firstResponse.body.contact.primaryContactId
      );
      expect(secondResponse.body.contact.secondaryContactIds).toHaveLength(0);
    });

    test("should create secondary contact with new information", async () => {
      // Create initial contact
      await request(app)
        .post("/api/identify")
        .send({
          email: "test3@example.com",
          phoneNumber: "+1234567892",
        })
        .expect(200);

      // Add new phone for same email
      const response = await request(app)
        .post("/api/identify")
        .send({
          email: "test3@example.com",
          phoneNumber: "+0987654321",
        })
        .expect(200);

      expect(response.body.contact.emails).toContain("test3@example.com");
      expect(response.body.contact.phoneNumbers).toContain("+1234567892");
      expect(response.body.contact.phoneNumbers).toContain("+0987654321");
      expect(response.body.contact.secondaryContactIds).toHaveLength(1);
    });

    test("should handle email-only requests", async () => {
      const response = await request(app)
        .post("/api/identify")
        .send({
          email: "email-only-test@example.com",
        })
        .expect(200);

      expect(response.body.contact.emails).toContain(
        "email-only-test@example.com"
      );
      expect(response.body.contact.phoneNumbers).toHaveLength(0);
    });

    test("should handle phone-only requests", async () => {
      const response = await request(app)
        .post("/api/identify")
        .send({
          phoneNumber: "+1234567893",
        })
        .expect(200);

      expect(response.body.contact.phoneNumbers).toContain("+1234567893");
      expect(response.body.contact.emails).toHaveLength(0);
    });

    test("should reject requests with no parameters", async () => {
      await request(app).post("/api/identify").send({}).expect(400);
    });

    test("should reject invalid email format", async () => {
      await request(app)
        .post("/api/identify")
        .send({
          email: "invalid-email",
        })
        .expect(400);
    });

    test("should reject invalid phone number format", async () => {
      await request(app)
        .post("/api/identify")
        .send({
          phoneNumber: "invalid-phone!@#",
        })
        .expect(400);
    });
  });

  describe("GET /api/health", () => {
    test("should return health status", async () => {
      const response = await request(app).get("/api/health").expect(200);

      expect(response.body).toHaveProperty("status", "healthy");
      expect(response.body).toHaveProperty("timestamp");
    });
  });

  describe("GET /api", () => {
    test("should return API information", async () => {
      const response = await request(app).get("/api").expect(200);

      expect(response.body).toHaveProperty("service");
      expect(response.body).toHaveProperty("endpoints");
    });
  });

  describe("Error handling", () => {
    test("should handle 404 for unknown routes", async () => {
      await request(app).get("/api/unknown").expect(404);
    });

    test("should handle malformed JSON", async () => {
      await request(app)
        .post("/api/identify")
        .set("Content-Type", "application/json")
        .send("{ invalid json }")
        .expect(400);
    });
  });
});
