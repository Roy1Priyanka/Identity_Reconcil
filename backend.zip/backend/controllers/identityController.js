const { AppError, asyncErrorHandler } = require("../middleware/errorHandler");

class IdentityController {
  constructor(identityService) {
    this.identityService = identityService;
  }

  
  healthCheck = asyncErrorHandler(async (req, res) => {
    res.status(200).json({
      status: "healthy",
      timestamp: new Date().toISOString(),
      version: process.env.npm_package_version || "1.0.0",
    });
  });

  identify = asyncErrorHandler(async (req, res) => {
    const { email, phoneNumber } = req.body;

    if (process.env.NODE_ENV === "development") {
      console.log("Identify request received:", { email, phoneNumber });
    }

    if (!email && !phoneNumber) {
      throw new AppError(
        "Either email or phoneNumber must be provided",
        400,
        "MISSING_PARAMETERS"
      );
    }

    try {
      const result = await this.identityService.identifyContact(
        email,
        phoneNumber
      );

      if (process.env.NODE_ENV === "development") {
        console.log("Identify response:", result);
      }

      res.status(200).json(result);
    } catch (error) {
      console.error("Error in identify endpoint:", error);

      throw error;
    }
  });

  getContact = asyncErrorHandler(async (req, res) => {
    const { id } = req.params;

    if (!id || isNaN(parseInt(id))) {
      throw new AppError(
        "Valid contact ID is required",
        400,
        "INVALID_CONTACT_ID"
      );
    }

    try {
      const result = await this.identityService.getContactResponse(
        parseInt(id)
      );

      if (!result) {
        throw new AppError("Contact not found", 404, "CONTACT_NOT_FOUND");
      }

      res.status(200).json(result);
    } catch (error) {
      console.error("Error in getContact endpoint:", error);
      throw error;
    }
  });

  apiInfo = asyncErrorHandler(async (req, res) => {
    res.status(200).json({
      service: "Identity Reconciliation Service",
      version: "1.0.0",
      endpoints: {
        identify: {
          method: "POST",
          path: "/identify",
          description:
            "Consolidate contact information based on email and/or phone number",
          parameters: {
            email: "string (optional)",
            phoneNumber: "string (optional)",
          },
          note: "At least one parameter (email or phoneNumber) must be provided",
        },
        health: {
          method: "GET",
          path: "/health",
          description: "Health check endpoint",
        },
      },
      documentation:
        "This service implements identity reconciliation for contact management",
    });
  });
}

module.exports = IdentityController;
