require("dotenv").config();

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");

const Database = require("./database/supabaseDatabase");
const Contact = require("./models/Contact");
const IdentityService = require("./services/IdentityService");
const IdentityController = require("./controllers/identityController");
const createRoutes = require("./routes");
const {
  globalErrorHandler,
  notFoundHandler,
  handleUncaughtExceptions,
} = require("./middleware/errorHandler");

class Server {
  constructor() {
    this.app = express();
    this.port = process.env.PORT || 3000;
    this.database = null;
    this.server = null;
  }

  async initialize() {
    try {
      handleUncaughtExceptions();

      this.database = new Database();
      await this.database.initialize();

      const contactModel = new Contact(this.database);
      const identityService = new IdentityService(contactModel);
      const identityController = new IdentityController(identityService);

      this.setupMiddleware();

      this.app.use("/api", createRoutes(identityController));

      this.setupErrorHandling();

      console.log("Server initialized successfully");
    } catch (error) {
      console.error("Failed to initialize server:", error);
      throw error;
    }
  }

  setupMiddleware() {
    this.app.use(
      helmet({
        contentSecurityPolicy: {
          directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'"],
          },
        },
      })
    );

    this.app.use(
      cors({
        origin: process.env.CORS_ORIGIN || "*",
        methods: ["GET", "POST"],
        allowedHeaders: ["Content-Type", "Authorization"],
        credentials: false,
      })
    );

    this.app.use(
      express.json({
        limit: "1kb",
        strict: true,
      })
    );

    this.app.disable("x-powered-by");

    if (process.env.NODE_ENV === "development") {
      this.app.use((req, res, next) => {
        console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
        next();
      });
    }

    this.app.get("/", (req, res) => {
      res.redirect("/api");
    });
  }

  setupErrorHandling() {
    this.app.use(notFoundHandler);

    this.app.use(globalErrorHandler);
  }

  async start() {
    try {
      await this.initialize();

      this.server = this.app.listen(this.port, () => {
        console.log(
          `🚀 Identity Reconciliation Service running on port ${this.port}`
        );
        console.log(`📊 Environment: ${process.env.NODE_ENV || "development"}`);
        console.log(`🔗 API available at: http://localhost:${this.port}/api`);
        console.log(
          `❤️  Health check: http://localhost:${this.port}/api/health`
        );
      });

      process.on("SIGTERM", () => this.shutdown("SIGTERM"));
      process.on("SIGINT", () => this.shutdown("SIGINT"));
    } catch (error) {
      console.error("Failed to start server:", error);
      process.exit(1);
    }
  }

  async shutdown(signal) {
    console.log(`\n🛑 Received ${signal}. Starting graceful shutdown...`);

    if (this.server) {
      this.server.close(async () => {
        console.log("📡 HTTP server closed");

        if (this.database) {
          try {
            await this.database.close();
            console.log("🗄️  Database connection closed");
          } catch (error) {
            console.error("Error closing database:", error);
          }
        }

        console.log("✅ Graceful shutdown completed");
        process.exit(0);
      });

      setTimeout(() => {
        console.error("⚠️  Forced shutdown after timeout");
        process.exit(1);
      }, 10000);
    } else {
      process.exit(0);
    }
  }
}

if (require.main === module) {
  const server = new Server();
  server.start().catch((error) => {
    console.error("💥 Server startup failed:", error);
    process.exit(1);
  });
}

module.exports = Server;
