const { createClient } = require("@supabase/supabase-js");
const { Pool } = require("pg");

class SupabaseDatabase {
  constructor() {
    this.supabase = null;
    this.pool = null;
    this.supabaseUrl = process.env.SUPABASE_URL;
    this.supabaseKey =
      process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;
    this.databaseUrl = process.env.DATABASE_URL;
  }

  async initialize() {
    try {
      // Initialize Supabase client
      if (!this.supabaseUrl || !this.supabaseKey) {
        throw new Error(
          "Supabase URL and key are required. Please check your environment variables."
        );
      }

      this.supabase = createClient(this.supabaseUrl, this.supabaseKey, {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      });

      // Initialize PostgreSQL connection pool for complex queries
      if (this.databaseUrl) {
        this.pool = new Pool({
          connectionString: this.databaseUrl,
          ssl: {
            rejectUnauthorized: false,
          },
          max: 10,
          idleTimeoutMillis: 30000,
          connectionTimeoutMillis: 2000,
        });

        // Test the connection
        const client = await this.pool.connect();
        await client.query("SELECT NOW()");
        client.release();
      }

      // Create tables if they don't exist
      await this.createTables();

      console.log("Supabase database initialized successfully");
    } catch (error) {
      console.error("Supabase database initialization failed:", error);
      throw error;
    }
  }

  async createTables() {
    const createContactsTable = `
      CREATE TABLE IF NOT EXISTS contacts (
        id BIGSERIAL PRIMARY KEY,
        phone_number TEXT,
        email TEXT,
        linked_id BIGINT,
        link_precedence TEXT CHECK(link_precedence IN ('secondary', 'primary')) DEFAULT 'primary',
        created_at TIMESTAMPTZ DEFAULT NOW(),
        updated_at TIMESTAMPTZ DEFAULT NOW(),
        deleted_at TIMESTAMPTZ,
        FOREIGN KEY (linked_id) REFERENCES contacts(id)
      )
    `;

    const createIndexes = [
      "CREATE INDEX IF NOT EXISTS idx_contacts_email ON contacts(email) WHERE deleted_at IS NULL",
      "CREATE INDEX IF NOT EXISTS idx_contacts_phone ON contacts(phone_number) WHERE deleted_at IS NULL",
      "CREATE INDEX IF NOT EXISTS idx_contacts_linked_id ON contacts(linked_id) WHERE deleted_at IS NULL",
      "CREATE INDEX IF NOT EXISTS idx_contacts_precedence ON contacts(link_precedence) WHERE deleted_at IS NULL",
      "CREATE INDEX IF NOT EXISTS idx_contacts_deleted ON contacts(deleted_at)",
      "CREATE INDEX IF NOT EXISTS idx_contacts_created_at ON contacts(created_at) WHERE deleted_at IS NULL",
    ];

    const createUpdatedAtTrigger = `
      CREATE OR REPLACE FUNCTION update_updated_at_column()
      RETURNS TRIGGER AS $$
      BEGIN
          NEW.updated_at = NOW();
          RETURN NEW;
      END;
      $$ language 'plpgsql';

      DROP TRIGGER IF EXISTS update_contacts_updated_at ON contacts;
      CREATE TRIGGER update_contacts_updated_at
          BEFORE UPDATE ON contacts
          FOR EACH ROW
          EXECUTE FUNCTION update_updated_at_column();
    `;

    try {
      // Use direct SQL execution for table creation
      if (this.pool) {
        const client = await this.pool.connect();
        try {
          await client.query(createContactsTable);

          for (const indexQuery of createIndexes) {
            await client.query(indexQuery);
          }

          await client.query(createUpdatedAtTrigger);
        } finally {
          client.release();
        }
      } else {
        // Fallback to Supabase client (less reliable for DDL)
        const { error } = await this.supabase.rpc("exec_sql", {
          sql: createContactsTable,
        });
        if (error) throw error;
      }
    } catch (error) {
      console.error("Error creating tables:", error);
      throw error;
    }
  }

  async query(text, params = []) {
    if (this.pool) {
      // Use PostgreSQL pool for complex queries
      const client = await this.pool.connect();
      try {
        const result = await client.query(text, params);
        return result;
      } finally {
        client.release();
      }
    } else {
      throw new Error("Database pool not available");
    }
  }

  async run(sql, params = []) {
    const result = await this.query(sql, params);
    return {
      id: result.rows[0]?.id,
      changes: result.rowCount,
    };
  }

  async get(sql, params = []) {
    const result = await this.query(sql, params);
    return result.rows[0] || null;
  }

  async all(sql, params = []) {
    const result = await this.query(sql, params);
    return result.rows;
  }

  // Supabase-specific methods using the Supabase client
  async supabaseInsert(table, data) {
    const { data: result, error } = await this.supabase
      .from(table)
      .insert(data)
      .select()
      .single();

    if (error) throw error;
    return result;
  }

  async supabaseUpdate(table, id, data) {
    const { data: result, error } = await this.supabase
      .from(table)
      .update(data)
      .eq("id", id)
      .select()
      .single();

    if (error) throw error;
    return result;
  }

  async supabaseSelect(table, filters = {}) {
    let query = this.supabase.from(table).select("*").is("deleted_at", null);

    // Apply filters
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== null && value !== undefined) {
        query = query.eq(key, value);
      }
    });

    const { data, error } = await query.order("created_at", {
      ascending: true,
    });

    if (error) throw error;
    return data || [];
  }

  async supabaseSelectOr(table, orConditions = []) {
    let query = this.supabase.from(table).select("*").is("deleted_at", null);

    // Build OR conditions
    if (orConditions.length > 0) {
      const orClause = orConditions
        .map((condition) => `${condition.column}.eq.${condition.value}`)
        .join(",");
      query = query.or(orClause);
    }

    const { data, error } = await query.order("created_at", {
      ascending: true,
    });

    if (error) throw error;
    return data || [];
  }

  async close() {
    try {
      if (this.pool) {
        await this.pool.end();
        console.log("PostgreSQL connection pool closed");
      }
      console.log("Supabase connection closed");
    } catch (error) {
      console.error("Error closing database connections:", error);
      throw error;
    }
  }

  // Transaction support using PostgreSQL
  async beginTransaction() {
    if (!this.pool) {
      throw new Error("Transactions require PostgreSQL pool connection");
    }
    const client = await this.pool.connect();
    await client.query("BEGIN");
    return client;
  }

  async commit(client) {
    await client.query("COMMIT");
    client.release();
  }

  async rollback(client) {
    await client.query("ROLLBACK");
    client.release();
  }

  // Helper method to convert snake_case to camelCase for API responses
  convertRowToCamelCase(row) {
    if (!row) return null;

    return {
      id: row.id,
      phoneNumber: row.phone_number,
      email: row.email,
      linkedId: row.linked_id,
      linkPrecedence: row.link_precedence,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
      deletedAt: row.deleted_at,
    };
  }

  convertRowsArrayToCamelCase(rows) {
    return rows.map((row) => this.convertRowToCamelCase(row));
  }
}

module.exports = SupabaseDatabase;
