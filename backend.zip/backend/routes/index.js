const express = require("express");
const rateLimit = require("express-rate-limit");
const {
  identifyValidation,
  handleValidationErrors,
  sanitizeInput,
  validateContentType,
  validateRequestSize,
} = require("../middleware/validation");

function createRoutes(identityController) {
  const router = express.Router();

  const limiter = rateLimit({
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutes
    max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100, // limit each IP to 100 requests per windowMs
    message: {
      error: "Too many requests from this IP",
      code: "RATE_LIMIT_EXCEEDED",
      retryAfter: "Please try again later",
    },
    standardHeaders: true,
    legacyHeaders: false,
  });

  router.use(limiter);

  router.get("/", identityController.apiInfo);

  router.get("/health", identityController.healthCheck);

  router.post(
    "/identify",
    validateContentType,
    validateRequestSize,
    sanitizeInput,
    identifyValidation,
    handleValidationErrors,
    identityController.identify
  );

  router.get("/contact/:id", identityController.getContact);

  return router;
}

module.exports = createRoutes;
