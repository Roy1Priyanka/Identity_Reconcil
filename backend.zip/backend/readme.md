# Identity Reconciliation Service (Supabase Edition)

A robust Node.js web service that consolidates contact information by linking different orders made with different contact information to the same individual. This service implements sophisticated identity reconciliation algorithms using **Supabase (PostgreSQL)** as the database backend to maintain data integrity while providing seamless contact management.

## 🚀 Features

- **Smart Contact Consolidation**: Automatically links contacts based on shared email addresses or phone numbers
- **Primary/Secondary Hierarchy**: Maintains contact relationships with clear precedence rules
- **Covert Operation Strategy**: Handles existing contact scenarios with discretion and precision
- **Supabase Integration**: Uses Supabase (PostgreSQL) for scalable, cloud-based data storage
- **Database Integrity**: Ensures seamless updates and maintains referential integrity
- **Comprehensive Validation**: Input validation with detailed error messages
- **Rate Limiting**: Built-in protection against abuse
- **Security First**: Helmet, CORS, and other security middleware included
- **Production Ready**: Graceful shutdown, error handling, and logging

## 📋 Requirements

- **Node.js**: Version 16.0.0 or higher
- **npm**: Version 8.0.0 or higher (comes with Node.js)
- **Supabase Account**: Free tier available at [supabase.com](https://supabase.com)

## 🛠️ Installation Guide

### Step 1: Install Node.js

1. **Download Node.js** from [nodejs.org](https://nodejs.org/)
2. **Install** the LTS version for your operating system
3. **Verify installation** by opening terminal/command prompt and running:
   ```bash
   node --version
   npm --version
   ```

### Step 2: Set Up Supabase

1. **Create a Supabase account** at [supabase.com](https://supabase.com)
2. **Create a new project** with your preferred settings
3. **Follow the detailed setup guide** in [SUPABASE_SETUP.md](./SUPABASE_SETUP.md)

### Step 3: Set Up Project

1. **Create project directory**:
   ```bash
   mkdir identity-reconciliation-service
   cd identity-reconciliation-service
   ```

2. **Save all the provided files** in the correct directory structure:
   ```
   identity-reconciliation-service/
   ├── package.json
   ├── .env.example
   ├── .env
   ├── .gitignore
   ├── server.js
   ├── README.md
   ├── SUPABASE_SETUP.md
   ├── database/
   │   ├── supabaseDatabase.js
   │   └── supabase-setup.sql
   ├── models/
   │   └── Contact.js
   ├── services/
   │   └── IdentityService.js
   ├── controllers/
   │   └── identityController.js
   ├── middleware/
   │   ├── validation.js
   │   └── errorHandler.js
   ├── routes/
   │   └── index.js
   └── tests/
       └── identity.test.js
   ```

3. **Install dependencies**:
   ```bash
   npm install
   ```

4. **Configure environment variables**:
   ```bash
   cp .env.example .env
   ```
   Then edit `.env` with your Supabase credentials (see [SUPABASE_SETUP.md](./SUPABASE_SETUP.md))

### Step 4: Database Setup

1. **Run the SQL setup script** in your Supabase SQL Editor:
   - Copy content from `database/supabase-setup.sql`
   - Paste and run in Supabase Dashboard → SQL Editor

## 🚀 Running the Service

### Development Mode
```bash
npm run dev
```
This starts the server with auto-restart on file changes using nodemon.

### Production Mode
```bash
npm start
```

### Testing
```bash
npm test
```

The service will be available at: `http://localhost:3000`

## 🗄️ Database Architecture (Supabase)

### Schema
```sql
CREATE TABLE contacts (
  id BIGSERIAL PRIMARY KEY,
  phone_number TEXT,
  email TEXT,
  linked_id BIGINT,
  link_precedence TEXT CHECK(link_precedence IN ('secondary', 'primary')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  deleted_at TIMESTAMPTZ,
  FOREIGN KEY (linked_id) REFERENCES contacts(id)
);
```

### Benefits of Supabase
- **Scalable PostgreSQL**: Enterprise-grade database performance
- **Real-time subscriptions**: Built-in real-time capabilities
- **Row Level Security**: Advanced security features
- **Automatic backups**: Data protection and recovery
- **Global CDN**: Fast data access worldwide
- **RESTful API**: Auto-generated APIs for your database and CORS settings

## 🚀 Running the Service

### Development Mode
```bash
npm run dev
```
This starts the server with auto-restart on file changes using nodemon.

### Production Mode
```bash
npm start
```

### Testing
```bash
npm test
```

The service will be available at: `http://localhost:3000`

## 📡 API Endpoints

### 1. Identity Reconciliation
**POST** `/api/identify`

Consolidates contact information and returns unified contact data.

**Request Body:**
```json
{
  "email": "string (optional)",
  "phoneNumber": "string (optional)"
}
```

**Response:**
```json
{
  "contact": {
    "primaryContactId": 1,
    "emails": ["test@example.com", "test2@example.com"],
    "phoneNumbers": ["+1234567890", "+0987654321"],
    "secondaryContactIds": [2, 3]
  }
}
```

**Examples:**

1. **New Contact Creation:**
   ```bash
   curl -X POST http://localhost:3000/api/identify \
     -H "Content-Type: application/json" \
     -d '{"email": "test@example.com", "phoneNumber": "+1234567890"}'
   ```

2. **Contact Linking:**
   ```bash
   curl -X POST http://localhost:3000/api/identify \
     -H "Content-Type: application/json" \
     -d '{"email": "test@example.com", "phoneNumber": "+0987654321"}'
   ```

### 2. Health Check
**GET** `/api/health`

Returns service health status.

### 3. API Information
**GET** `/api`

Returns API documentation and available endpoints.

## 🏗️ Architecture

### Core Components

1. **Database Layer** (`database/supabaseDatabase.js`): Supabase/PostgreSQL with connection management
2. **Model Layer** (`models/Contact.js`): Contact data operations and queries
3. **Service Layer** (`services/IdentityService.js`): Business logic for identity reconciliation
4. **Controller Layer** (`controllers/identityController.js`): HTTP request handling
5. **Middleware**: Validation, error handling, and security
6. **Routes** (`routes/index.js`): API endpoint definitions

### Supabase Integration Features

- **Dual Connection Strategy**: Uses both Supabase client and direct PostgreSQL for optimal performance
- **Advanced Queries**: Complex recursive CTEs for contact hierarchy resolution
- **Transaction Support**: ACID compliance for data consistency
- **Connection Pooling**: Efficient resource management
- **Real-time Capabilities**: Ready for real-time features if needed

## 🔐 Security Features

- **Helmet**: Security headers
- **CORS**: Cross-origin resource sharing configuration
- **Rate Limiting**: Prevents abuse (100 requests per 15 minutes per IP)
- **Input Validation**: Comprehensive request validation
- **SQL Injection Protection**: Parameterized queries
- **Error Sanitization**: No sensitive data in error responses

## 🧪 Testing Strategy

The service includes comprehensive tests covering:

- **Unit Testing**: Individual component functionality
- **Integration Testing**: End-to-end API testing
- **Edge Cases**: Concurrent requests, data validation, error scenarios
- **Performance Testing**: Rate limiting and resource management

Run tests with:
```bash
npm test
```

## 🔄 Identity Reconciliation Logic

### Scenario 1: New Contact
- **Input**: New email/phone combination
- **Action**: Create primary contact
- **Result**: Single primary contact entry

### Scenario 2: Exact Match
- **Input**: Existing email/phone combination
- **Action**: Return existing contact hierarchy
- **Result**: No database changes

### Scenario 3: Partial Match (New Information)
- **Input**: Known email with new phone (or vice versa)
- **Action**: Create secondary contact linked to existing primary
- **Result**: Extended contact information

### Scenario 4: Contact Consolidation
- **Input**: Information that links two separate primary contacts
- **Action**: Convert newer primary to secondary, link to older primary
- **Result**: Consolidated contact hierarchy

## 🚨 Error Handling

The service implements comprehensive error handling:

- **400 Bad Request**: Invalid input, validation failures
- **404 Not Found**: Unknown endpoints
- **413 Payload Too Large**: Request size exceeding limits
- **429 Too Many Requests**: Rate limit exceeded
- **500 Internal Server Error**: Database or system errors

## 📊 Monitoring & Logging

- **Health Check**: `/api/health` endpoint for monitoring
- **Request Logging**: Detailed logging in development mode
- **Error Tracking**: Comprehensive error logging with stack traces
- **Performance Metrics**: Response time and database query optimization

## 🔧 Configuration Options

Environment variables in `.env`:

```bash
# Server Configuration
PORT=3000
NODE_ENV=development

# Supabase Configuration
SUPABASE_URL=https://your-project-ref.supabase.co
SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key

# Database Configuration (PostgreSQL via Supabase)
DATABASE_URL=postgresql://postgres:[password]@db.[project-ref].supabase.co:5432/postgres

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100

# Security
CORS_ORIGIN=*
```

### Supabase Environment Setup

1. **Get credentials** from your Supabase project dashboard
2. **Copy** `.env.example` to `.env`
3. **Update** with your actual Supabase credentials
4. **Run** the database setup script in Supabase SQL Editor

See [SUPABASE_SETUP.md](./SUPABASE_SETUP.md) for detailed instructions.

## 🚀 Deployment

### Local Deployment
1. Follow installation steps above
2. Set up Supabase project and configure `.env`
3. Run `npm start`
4. Service available at `http://localhost:3000`

### Production Deployment

#### Using Vercel (Recommended)
1. **Connect your GitHub repository** to Vercel
2. **Set environment variables** in Vercel dashboard
3. **Deploy** - Vercel will handle the build process

#### Using Railway
1. **Connect your GitHub repository** to Railway
2. **Set environment variables** in Railway dashboard
3. **Deploy** - Railway provides PostgreSQL if needed

#### Using Heroku
1. **Create Heroku app**: `heroku create your-app-name`
2. **Set environment variables**: `heroku config:set SUPABASE_URL=...`
3. **Deploy**: `git push heroku main`

#### Using Docker
```dockerfile
FROM node:16-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
```

### Environment-Specific Configuration

- **Development**: Use Supabase development project
- **Staging**: Use separate Supabase staging project  
- **Production**: Use production Supabase project with enhanced security

## 🐛 Troubleshooting

### Common Issues

1. **Supabase Connection Error**
   - Verify `SUPABASE_URL` and API keys in `.env`
   - Check if database setup script ran successfully
   - Ensure Supabase project is active

2. **Database Permission Issues**
   - Verify you're using the `SUPABASE_SERVICE_ROLE_KEY`
   - Check Row Level Security policies in Supabase
   - Ensure proper permissions are set

3. **Port Already in Use**
   - Change PORT in `.env` file
   - Kill existing process: `lsof -ti:3000 | xargs kill`

4. **Module Not Found Errors**
   - Run `npm install` to install dependencies
   - Check Node.js version compatibility

5. **API Timeout Errors**
   - Check your internet connection
   - Verify Supabase project status
   - Check if you've hit rate limits

### Debug Mode
Enable detailed logging by setting `NODE_ENV=development` in `.env`.

### Testing Supabase Connection
```bash
# Test the health endpoint
curl http://localhost:3000/api/health

# Test basic functionality
curl -X POST http://localhost:3000/api/identify \
  -H "Content-Type: application/json" \
  -d '{"email": "test@example.com", "phoneNumber": "+1234567890"}'
```

## 📈 Performance Optimization

- **Database Indexing**: Optimized indexes on email, phone, and linked_id
- **Connection Pooling**: Efficient PostgreSQL connection management
- **Request Validation**: Early validation to prevent unnecessary processing
- **Memory Management**: Proper resource cleanup and garbage collection
- **Supabase Edge Functions**: Ready for serverless optimization
- **Caching Strategy**: Implements intelligent query caching where appropriate

## 🔐 Security Features

- **Helmet**: Security headers
- **CORS**: Cross-origin resource sharing configuration
- **Rate Limiting**: Prevents abuse (100 requests per 15 minutes per IP)
- **Input Validation**: Comprehensive request validation
- **SQL Injection Protection**: Parameterized queries
- **Row Level Security**: Supabase RLS for data access control
- **Error Sanitization**: No sensitive data in error responses
- **Environment Variable Protection**: Sensitive data in environment variables only

## 📊 Monitoring & Observability

- **Health Check**: `/api/health` endpoint for monitoring
- **Request Logging**: Detailed logging in development mode
- **Error Tracking**: Comprehensive error logging with stack traces
- **Performance Metrics**: Response time and database query optimization
- **Supabase Dashboard**: Built-in monitoring and analytics
- **Real-time Metrics**: Available through Supabase interface

---

**Built with ❤️ using Supabase for Moonrider's Identity Reconciliation Challenge**

## 🔗 Quick Links

- **[Supabase Setup Guide](./SUPABASE_SETUP.md)** - Detailed Supabase configuration
- **[Supabase Dashboard](https://supabase.com/dashboard)** - Manage your database
- **[API Documentation](#-api-endpoints)** - Complete API reference
- **[Testing Guide](#-testing-strategy)** - How to test the service