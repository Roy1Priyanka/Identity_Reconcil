const { body, validationResult } = require("express-validator");

const identifyValidation = [
  body("email")
    .optional()
    .isEmail()
    .withMessage("Email must be a valid email address")
    .normalizeEmail()
    .isLength({ max: 255 })
    .withMessage("Email must not exceed 255 characters"),

  body("phoneNumber")
    .optional()
    .isString()
    .withMessage("Phone number must be a string")
    .isLength({ min: 1, max: 20 })
    .withMessage("Phone number must be between 1 and 20 characters")
    .matches(/^[\d\-\+\(\)\s]+$/)
    .withMessage("Phone number contains invalid characters"),

  body().custom((value, { req }) => {
    if (!req.body.email && !req.body.phoneNumber) {
      throw new Error("Either email or phoneNumber must be provided");
    }
    return true;
  }),
];

const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    const errorMessages = errors.array().map((error) => ({
      field: error.path || error.param,
      message: error.msg,
      value: error.value,
    }));

    return res.status(400).json({
      error: "Validation failed",
      details: errorMessages,
    });
  }

  next();
};

const sanitizeInput = (req, res, next) => {
  if (req.body.email) {
    req.body.email = req.body.email.trim();
  }

  if (req.body.phoneNumber) {
    req.body.phoneNumber = req.body.phoneNumber.trim();
  }

  if (req.body.email === "") {
    req.body.email = null;
  }

  if (req.body.phoneNumber === "") {
    req.body.phoneNumber = null;
  }

  next();
};

const validateContentType = (req, res, next) => {
  if (req.method === "POST" && !req.is("application/json")) {
    return res.status(400).json({
      error: "Content-Type must be application/json",
    });
  }
  next();
};

const validateRequestSize = (req, res, next) => {
  const maxSize = 1024;

  if (
    req.headers["content-length"] &&
    parseInt(req.headers["content-length"]) > maxSize
  ) {
    return res.status(413).json({
      error: "Request payload too large",
    });
  }

  next();
};

module.exports = {
  identifyValidation,
  handleValidationErrors,
  sanitizeInput,
  validateContentType,
  validateRequestSize,
};
