
class AppError extends Error {
  constructor(message, statusCode, code = null) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.isOperational = true;

    Error.captureStackTrace(this, this.constructor);
  }
}

const handleDatabaseError = (err) => {
  console.error("Database error:", err);

  if (err.code) {
    switch (err.code) {
      case "SQLITE_CONSTRAINT":
        return new AppError(
          "Data constraint violation",
          400,
          "CONSTRAINT_VIOLATION"
        );
      case "SQLITE_BUSY":
        return new AppError(
          "Database is busy, please try again",
          503,
          "DATABASE_BUSY"
        );
      case "SQLITE_LOCKED":
        return new AppError(
          "Database is locked, please try again",
          503,
          "DATABASE_LOCKED"
        );
      case "SQLITE_CORRUPT":
        return new AppError(
          "Database corruption detected",
          500,
          "DATABASE_CORRUPT"
        );
      default:
        return new AppError("Database operation failed", 500, "DATABASE_ERROR");
    }
  }

  return new AppError("Internal database error", 500, "DATABASE_ERROR");
};

const asyncErrorHandler = (fn) => {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};

const globalErrorHandler = (err, req, res, next) => {
  console.error("Error occurred:", {
    message: err.message,
    stack: err.stack,
    url: req.url,
    method: req.method,
    body: req.body,
    timestamp: new Date().toISOString(),
  });

  let error = err;

  if (err.code && err.code.startsWith("SQLITE_")) {
    error = handleDatabaseError(err);
  }

  if (err.type === "entity.parse.failed") {
    error = new AppError("Invalid JSON payload", 400, "INVALID_JSON");
  }

  if (!(error instanceof AppError)) {
    error = new AppError("Internal server error", 500, "INTERNAL_ERROR");
  }

  const response = {
    error: error.message,
    code: error.code || "UNKNOWN_ERROR",
  };

  if (process.env.NODE_ENV === "development") {
    response.stack = error.stack;
    response.details = {
      originalMessage: err.message,
      originalStack: err.stack,
    };
  }

  res.status(error.statusCode || 500).json(response);
};

const notFoundHandler = (req, res) => {
  res.status(404).json({
    error: "Route not found",
    code: "ROUTE_NOT_FOUND",
    message: `Cannot ${req.method} ${req.url}`,
  });
};

const handleUncaughtExceptions = () => {
  process.on("uncaughtException", (err) => {
    console.error("Uncaught Exception:", err);
    process.exit(1);
  });

  process.on("unhandledRejection", (reason, promise) => {
    console.error("Unhandled Rejection at:", promise, "reason:", reason);
    process.exit(1);
  });
};

module.exports = {
  AppError,
  asyncErrorHandler,
  globalErrorHandler,
  notFoundHandler,
  handleUncaughtExceptions,
};
