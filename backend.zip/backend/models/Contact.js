class Contact {
  constructor(database) {
    this.db = database;
  }

  async findByEmailOrPhone(email, phoneNumber) {
    try {
      const query = `
          SELECT * FROM contacts 
          WHERE (email = $1 OR phone_number = $2) 
          AND deleted_at IS NULL 
          ORDER BY created_at ASC
        `;
      const result = await this.db.all(query, [email, phoneNumber]);
      return this.db.convertRowsArrayToCamelCase(result);
    } catch (error) {
      console.error("Error in findByEmailOrPhone:", error);
      throw error;
    }
  }

  async findByEmail(email) {
    try {
      const result = await this.db.supabaseSelect("contacts", { email });
      return this.db.convertRowsArrayToCamelCase(result);
    } catch (error) {
      console.error("Error in findByEmail:", error);
      throw error;
    }
  }

  async findByPhone(phoneNumber) {
    try {
      const result = await this.db.supabaseSelect("contacts", {
        phone_number: phoneNumber,
      });
      return this.db.convertRowsArrayToCamelCase(result);
    } catch (error) {
      console.error("Error in findByPhone:", error);
      throw error;
    }
  }

  async findById(id) {
    try {
      const result = await this.db.supabaseSelect("contacts", { id });
      const contact = result[0] || null;
      return contact ? this.db.convertRowToCamelCase(contact) : null;
    } catch (error) {
      console.error("Error in findById:", error);
      throw error;
    }
  }

  async findPrimaryContact(id) {
    try {
      const query = `
          WITH RECURSIVE contact_hierarchy AS (
            SELECT id, phone_number, email, linked_id, link_precedence, created_at, updated_at
            FROM contacts 
            WHERE id = $1 AND deleted_at IS NULL
            
            UNION ALL
            
            SELECT c.id, c.phone_number, c.email, c.linked_id, c.link_precedence, c.created_at, c.updated_at
            FROM contacts c
            INNER JOIN contact_hierarchy ch ON c.id = ch.linked_id
            WHERE c.deleted_at IS NULL
          )
          SELECT * FROM contact_hierarchy 
          WHERE link_precedence = 'primary' OR linked_id IS NULL
          ORDER BY created_at ASC
          LIMIT 1
        `;
      const result = await this.db.get(query, [id]);
      return result ? this.db.convertRowToCamelCase(result) : null;
    } catch (error) {
      console.error("Error in findPrimaryContact:", error);
      throw error;
    }
  }

  async findAllLinkedContacts(primaryId) {
    try {
      const query = `
          WITH RECURSIVE linked_contacts AS (
            SELECT id, phone_number, email, linked_id, link_precedence, created_at, updated_at
            FROM contacts 
            WHERE id = $1 AND deleted_at IS NULL
            
            UNION ALL
            
            SELECT c.id, c.phone_number, c.email, c.linked_id, c.link_precedence, c.created_at, c.updated_at
            FROM contacts c
            INNER JOIN linked_contacts lc ON c.linked_id = lc.id
            WHERE c.deleted_at IS NULL
          )
          SELECT DISTINCT * FROM linked_contacts 
          ORDER BY created_at ASC
        `;
      const result = await this.db.all(query, [primaryId]);
      return this.db.convertRowsArrayToCamelCase(result);
    } catch (error) {
      console.error("Error in findAllLinkedContacts:", error);
      throw error;
    }
  }

  async create(contactData) {
    try {
      const { phoneNumber, email, linkedId, linkPrecedence } = contactData;

      const insertData = {
        phone_number: phoneNumber || null,
        email: email || null,
        linked_id: linkedId || null,
        link_precedence: linkPrecedence || "primary",
      };

      const result = await this.db.supabaseInsert("contacts", insertData);
      return this.db.convertRowToCamelCase(result);
    } catch (error) {
      console.error("Error in create:", error);
      throw error;
    }
  }

  async updateLinkPrecedence(contactId, linkPrecedence, linkedId = null) {
    try {
      const updateData = {
        link_precedence: linkPrecedence,
        linked_id: linkedId,
      };

      const result = await this.db.supabaseUpdate(
        "contacts",
        contactId,
        updateData
      );
      return this.db.convertRowToCamelCase(result);
    } catch (error) {
      console.error("Error in updateLinkPrecedence:", error);
      throw error;
    }
  }

  async getContactHierarchy(email, phoneNumber) {
    try {
      const matchingContacts = await this.findByEmailOrPhone(
        email,
        phoneNumber
      );

      if (matchingContacts.length === 0) {
        return null;
      }

      const primaryContacts = [];
      const secondaryContacts = [];

      for (const contact of matchingContacts) {
        if (contact.linkPrecedence === "primary") {
          primaryContacts.push(contact);
        } else {
          secondaryContacts.push(contact);
        }
      }

      if (primaryContacts.length === 0 && secondaryContacts.length > 0) {
        for (const secondary of secondaryContacts) {
          const primary = await this.findPrimaryContact(secondary.linkedId);
          if (primary && !primaryContacts.find((p) => p.id === primary.id)) {
            primaryContacts.push(primary);
          }
        }
      }

      const oldestPrimary = primaryContacts.reduce((oldest, current) => {
        return new Date(current.createdAt) < new Date(oldest.createdAt)
          ? current
          : oldest;
      });

      const allLinkedContacts = await this.findAllLinkedContacts(
        oldestPrimary.id
      );

      return {
        primaryContact: oldestPrimary,
        allContacts: allLinkedContacts,
      };
    } catch (error) {
      console.error("Error in getContactHierarchy:", error);
      throw error;
    }
  }

  async consolidateContacts(contacts) {
    if (contacts.length <= 1) {
      return contacts;
    }

    let client = null;

    try {
      client = await this.db.beginTransaction();

      const sortedContacts = contacts.sort(
        (a, b) => new Date(a.createdAt) - new Date(b.createdAt)
      );
      const primaryContact = sortedContacts[0];
      const contactsToUpdate = sortedContacts.slice(1);

      await client.query(
        "UPDATE contacts SET link_precedence = $1, linked_id = NULL, updated_at = NOW() WHERE id = $2",
        ["primary", primaryContact.id]
      );

      for (const contact of contactsToUpdate) {
        if (contact.linkPrecedence === "primary") {
          await client.query(
            "UPDATE contacts SET link_precedence = $1, linked_id = $2, updated_at = NOW() WHERE id = $3",
            ["secondary", primaryContact.id, contact.id]
          );
        }
      }

      await this.db.commit(client);

      return await this.findAllLinkedContacts(primaryContact.id);
    } catch (error) {
      if (client) {
        await this.db.rollback(client);
      }
      console.error("Error in consolidateContacts:", error);
      throw error;
    }
  }
}

module.exports = Contact;
